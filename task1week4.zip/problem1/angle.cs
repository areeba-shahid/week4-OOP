﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem1.BL
{
    internal class angle
    {
        public int degree;
        public float minute;  
        public char direction;

        public string DisplayAngle()
        {
            return $"{degree}*{minute}' {direction}";
        }
    }
}
