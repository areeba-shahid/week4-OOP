﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using problem1.BL;

namespace problem1
{
    internal class Program
    {
        static angle Angle = new angle();
        static angle Angle2 = new angle();
       static ship Ship = new ship();
        static List<ship> ShipList = new List<ship>();
        static List<angle> AngleList = new List<angle>();
        static void Main(string[] args)
        {
            int choice = 0;
            while (choice != 5)
            {
                Console.WriteLine("Menu...");
                Console.WriteLine("1. Add Ship");
                Console.WriteLine("2. View Ship Position");
                Console.WriteLine("3. View Ship Serial Number ");
                Console.WriteLine("4. Change Ship Position");
                Console.WriteLine("5. Exit");
                Console.WriteLine("Enter Your Option: ");
                choice = int.Parse(Console.ReadLine());

                if (choice == 1)
                {
                    AddShip();
                    Console.ReadLine();
                    Console.Clear();
                }   
                if (choice == 2)
                {
                    ViewShip();
                    Console.ReadLine();
                    Console.Clear();
                }
                if (choice == 3) 
                {
                    ViewShipSerialNumber();
                    Console.ReadLine();
                    Console.Clear();
                }
                if (choice == 4) 
                {
                    UpdatePosition();
                    Console.ReadLine();
                    Console.Clear();
                }
                if (choice > 5 )
                {
                    Console.WriteLine("Please choose an option between 1 & 5...");
                    Console.ReadLine();
                    Console.Clear();
                }
            }
        }
        static void AddShip()
        {
            Console.WriteLine("Enter Ship Number: ");
            Ship.serial = Console.ReadLine();
            Console.WriteLine("Enter Ship Latitude: ");
            Console.WriteLine("Enter Latitude's Degree: ");
            Angle.degree = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Latitude's Minute: ");
            Angle.minute = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Latitude's Direction: ");
            Angle.direction = char.Parse(Console.ReadLine());
            Console.WriteLine("Enter Ship Longitude: ");
            Console.WriteLine("Enter Longitude's Degree: ");
            Angle2.degree = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Longitude's Minute: ");
            Angle2.minute = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Longitude's Direction: ");
            Angle2.direction = char.Parse(Console.ReadLine());

           ShipList.Add(Ship);
        }
        static void ViewShip()
        {
            Console.WriteLine("Enter Ship Serial Number to find it's position: ");
            string findShip = Console.ReadLine();
            foreach (var Ship in ShipList)
            {
                if (findShip == Ship.serial)
                {
                    Console.WriteLine($"Ship is at {Angle.degree}\u00b0{Angle.minute}' {Angle.direction} and {Angle2.degree}\u00b0{Angle2.minute}' {Angle2.direction}");
                }
                else
                {
                    Console.WriteLine("Ship Not Found...");
                }
            }
        }
        static void ViewShipSerialNumber()
        {
            Console.WriteLine("Enter the Ship Latitude: ");
            string findShip = Console.ReadLine();
            string find = Angle.DisplayAngle();
            if (find == findShip )
            {
                Console.WriteLine(Ship.serial);
            }
        }
        static void UpdatePosition()
        {
            Console.WriteLine("Enter Ship's Serial Number whose position you want to change: ");
            string findShip = Console.ReadLine();
            foreach (ship Ship in ShipList)
            {
                if (findShip == Ship.serial)
                {
                    Console.WriteLine("Enter Ship Latitude: ");
                    Console.WriteLine("Enter Latitude's Degree: ");
                    Angle.degree = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Latitude's Minute: ");
                    Angle.minute = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Latitude's Direction: ");
                    Angle.direction = char.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Ship Longitude: ");
                    Console.WriteLine("Enter Longitude's Degree: ");
                    Angle2.degree = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Longitude's Minute: ");
                    Angle2.minute = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Longitude's Direction: ");
                    Angle2.direction = char.Parse(Console.ReadLine());
                }
                else
                {
                    Console.WriteLine("Ship Not Found...");
                }
            }

        }
    }
}
